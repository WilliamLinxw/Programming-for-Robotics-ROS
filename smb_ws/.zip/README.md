# Programming-for-Robotics-ROS
Exercise code for the course Programming for Robotics: ROS at ETH Zurich

The exercises are based on the mobile robot SuperMegaBot (SMB) for the ETHZ Robotics Summer School.

During the exercise, I found the [ros_best_practices](https://github.com/leggedrobotics/ros_best_practices) template for a ROS package very helpful, which is maintained by the ETH Zurich Robotics Systems Lab. It is also a good starting point for developing a ROS package.
